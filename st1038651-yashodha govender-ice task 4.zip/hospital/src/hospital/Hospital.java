/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package hospital;

import java.util.ArrayList;
import java.util.Scanner;

// Base class Person
class Person {
    protected String firstName;
    protected String lastName;
    protected String address;
    protected String zipCode;
    protected String phoneNumber;

    // Method to input data for a person
    public void inputData(Scanner scanner) {
        System.out.println("Enter first name: ");
        firstName = scanner.nextLine();
        System.out.println("Enter last name: ");
        lastName = scanner.nextLine();
        System.out.println("Enter address: ");
        address = scanner.nextLine();
        System.out.println("Enter zip code: ");
        zipCode = scanner.nextLine();
        System.out.println("Enter phone number: ");
        phoneNumber = scanner.nextLine();
    }

    // Method to display person data
    public void displayData() {
        System.out.printf("Name: %s %s, Address: %s, Zip: %s, Phone: %s\n",
                          firstName, lastName, address, zipCode, phoneNumber);
    }
}

// Class HospitalStaff that inherits from Person
class HospitalStaff extends Person {
    protected String staffID;
    protected double salary;
    protected String department;

    @Override
    public void inputData(Scanner scanner) {
        super.inputData(scanner); // Call Person's input method
        System.out.println("Enter staff ID: ");
        staffID = scanner.nextLine();
        System.out.println("Enter salary: ");
        salary = scanner.nextDouble();
        scanner.nextLine();  // Consume the newline
        System.out.println("Enter department: ");
        department = scanner.nextLine();
    }

    @Override
    public void displayData() {
        super.displayData(); // Call Person's display method
        System.out.printf("Staff ID: %s, Salary: %.2f, Department: %s\n", staffID, salary, department);
    }
}

// Class Doctor that inherits from HospitalStaff
class Doctor extends HospitalStaff {
    private boolean isSpecialist;

    @Override
    public void inputData(Scanner scanner) {
        super.inputData(scanner); // Call HospitalStaff's input method
        System.out.println("Is the doctor a specialist? (true/false): ");
        isSpecialist = scanner.nextBoolean();
        scanner.nextLine(); // Consume the newline
    }

    @Override
    public void displayData() {
        super.displayData(); // Call HospitalStaff's display method
        System.out.printf("Specialist: %b\n", isSpecialist);
    }
}

// Class Patient that inherits from Person
class Patient extends Person {
    private String medicalRecordNumber;
    private ArrayList<String> ailments = new ArrayList<>();

    @Override
    public void inputData(Scanner scanner) {
        super.inputData(scanner); // Call Person's input method
        System.out.println("Enter medical record number: ");
        medicalRecordNumber = scanner.nextLine();
        System.out.println("Enter patient's ailments (comma separated): ");
        String ailmentInput = scanner.nextLine();
        for (String ailment : ailmentInput.split(",")) {
            ailments.add(ailment.trim());
        }
    }

    @Override
    public void displayData() {
        super.displayData(); // Call Person's display method
        System.out.printf("Medical Record Number: %s, Ailments: %s\n", medicalRecordNumber, ailments);
    }
}

// Main class Hospital
public class Hospital {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        HospitalStaff[] hospitalStaffs = new HospitalStaff[4];
        Doctor[] doctors = new Doctor[3];
        Patient[] patients = new Patient[7];

        int staffCount = 0, doctorCount = 0, patientCount = 0;
        char choice;

        while (true) {
            System.out.println("Enter H for HospitalStaff, D for Doctor, P for Patient, or Q to quit: ");
            choice = scanner.nextLine().charAt(0);

            if (choice == 'Q' || choice == 'q') {
                break;
            }

            switch (choice) {
                case 'H':
                case 'h':
                    if (staffCount < hospitalStaffs.length) {
                        hospitalStaffs[staffCount] = new HospitalStaff();
                        hospitalStaffs[staffCount].inputData(scanner);
                        staffCount++;
                    } else {
                        System.out.println("Error: Maximum of 4 HospitalStaff members reached.");
                    }
                    break;
                case 'D':
                case 'd':
                    if (doctorCount < doctors.length) {
                        doctors[doctorCount] = new Doctor();
                        doctors[doctorCount].inputData(scanner);
                        doctorCount++;
                    } else {
                        System.out.println("Error: Maximum of 3 Doctors reached.");
                    }
                    break;
                case 'P':
                case 'p':
                    if (patientCount < patients.length) {
                        patients[patientCount] = new Patient();
                        patients[patientCount].inputData(scanner);
                        patientCount++;
                    } else {
                        System.out.println("Error: Maximum of 7 Patients reached.");
                    }
                    break;
                default:
                    System.out.println("Invalid choice.");
            }
        }

        // Display Report
        System.out.println("\n--- Hospital Staff ---");
        if (staffCount == 0) {
            System.out.println("No Hospital Staff data entered.");
        } else {
            for (int i = 0; i < staffCount; i++) {
                hospitalStaffs[i].displayData();
            }
        }

        System.out.println("\n--- Doctors ---");
        if (doctorCount == 0) {
            System.out.println("No Doctor data entered.");
        } else {
            for (int i = 0; i < doctorCount; i++) {
                doctors[i].displayData();
            }
        }

        System.out.println("\n--- Patients ---");
        if (patientCount == 0) {
            System.out.println("No Patient data entered.");
        } else {
            for (int i = 0; i < patientCount; i++) {
                patients[i].displayData();
            }
        }

        scanner.close(); // Close scanner resource
    }
}
